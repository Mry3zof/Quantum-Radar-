import java.util.Optional;

public class SeatBeltRule implements Rule {

    private double fee;

    public SeatBeltRule(double fee) {
        this.fee = fee;
    }

    public String getRuleName() {
        return "Seatbelt not fastened";
    }

    public Optional<Violation> evaluate(Observation observation) {
        if (!observation.isSeatbeltFastened()) {
            return Optional.of(new Violation(getRuleName(), "Seatbelt not fastened", fee));
        }
        return Optional.empty();
    }
}