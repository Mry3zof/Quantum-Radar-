import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        RadarSystem radar = new RadarSystem();

        // Register rules
        radar.addRule(new SeatBeltRule(100));
        radar.addRule(new SpeedLimitRule(CarType.PRIVATE, 80, 300));
        radar.addRule(new SpeedLimitRule(CarType.TRUCK, 60, 300));

        // Feed observations
        System.out.println("Observation 1:");
        radar.handleObservation(new Observation(
                "ABC1234", LocalDate.of(2026, 7, 23), CarType.PRIVATE, 94, false));

        System.out.println();
        System.out.println("Observation 2 (compliant):");
        radar.handleObservation(new Observation(
                "XYZ999", LocalDate.of(2026, 7, 23), CarType.PRIVATE, 70, true));

        System.out.println();
        System.out.println("Observation 3:");
        radar.handleObservation(new Observation(
                "TRK555", LocalDate.of(2026, 7, 23), CarType.TRUCK, 75, true));

        // Reports
        System.out.println();
        radar.printFineTotals();

        System.out.println();
        radar.printViolationCounts();
    }
}