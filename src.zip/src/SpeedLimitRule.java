import java.util.Optional;

public class SpeedLimitRule implements Rule {

    private CarType carType;
    private double maxSpeed;
    private double fee;

    public SpeedLimitRule(CarType carType, double maxSpeed, double fee) {
        this.carType = carType;
        this.maxSpeed = maxSpeed;
        this.fee = fee;
    }

    public String getRuleName() {
        return "Max speed exceeded (" + carType + ")";
    }

    public Optional<Violation> evaluate(Observation observation) {
        if (observation.getCarType() == carType && observation.getSpeed() > maxSpeed) {
            String description = String.format(
                    "speed of %.0f exceeded max allowed %.0f", observation.getSpeed(), maxSpeed);
            return Optional.of(new Violation(getRuleName(), description, fee));
        }
        return Optional.empty();
    }
}